num1 = int(input("첫번째 숫자 : "))
num2 = int(input("두번째 숫자 : "))
num3 = int(input("세번째 숫자 : "))

print(num1 +num2 +num3)
print(num1 -num2 -num3)
print(num1*num2*num3)
print(format(num1/num2/num3, ".4f"))
